import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Vuelo } from '../../models/vuelo.model';
import { VuelosService } from '../../services/vuelos.service';
import { AlertController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

/**
 * Generated class for the ReservasPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reservas',
  templateUrl: 'reservas.html',
})
export class ReservasPage {

  reservas: Observable <Vuelo[]>;

  constructor(public navCtrl: NavController, public navParams: NavParams, private VuelosService:VuelosService, public alertCtrl: AlertController) {
  }

  ionViewWillEnter() {
    this.reservas = this.VuelosService
    .getVuelos()  //Retorna la DB
    .snapshotChanges() //retorna los cambios en la DB (key and value)
    .map(
      /*
      Estas líneas retornan un array de  objetos con el id del registro y su contenido
      {
        "key":"value",
        contact.name,
        contact.organization,
        ...
      }
      */
    changes => {
      return changes.map(c=> ({
        key: c.payload.key, ...c.payload.val()
      }));
    });
  }

  reservaCorrecta(vuelo: Vuelo){
    let fechaVuelo = this.parseDate(vuelo.ida);
    let fechaActual = new Date(Date.parse(Date()));
    let tiempoEntreReservas = this.dateDiff(fechaVuelo, fechaActual);
    if(tiempoEntreReservas < 24){
      this.facturarVuelo(vuelo);
    }
    else{
      this.errorFacturar();
    }
  }

  dateDiff(date1: Date, date2: Date): number {
    let diff = date1.getTime() - date2.getTime();
    return Math.round((diff) / (1000 * 60 * 60));
  }

  parseDate(date: string): Date {
    let mdy: String[] = date.split('-');
    return new Date(Number(mdy[0]), Number(mdy[1]) - 1, Number(mdy[2]));
  }

  facturarVuelo(vuelo: Vuelo) {
    const alert = this.alertCtrl.create({
      title: 'Facturación',
      subTitle: 'Datos para facturación',
      inputs: [
        {
          name: 'nom',
          placeholder: 'Nombre'
        },
        {
          name: 'ape',
          placeholder: 'Apellidos'
        },
        {
          name: 'pas',
          placeholder: 'Pasaporte'
        },
        {
          name: 'telf',
          placeholder: 'Número de contacto'
        },
      ],
      buttons: [{ text: 'Cancel' },
      { text: 'OK', handler: data => {
              this.validate(data, vuelo);}
      }]
    });
    alert.present();
  }  

  validate(data: any, vuelo: Vuelo){ // Comprobacion de campos vacíos
    
    if(data.nom == "" || data.ape == "" || data.pas == "" || data.telf == ""){
      const alert = this.alertCtrl.create({
        title: 'Error',
        message: 'Debes rellenar todos los campos',
        buttons: [{ text: 'OK' }]
      });
      alert.present();
    }

    else{
      this.VuelosService.addTarjeta(vuelo, data.nom, data.ape, data.pas, data.telf);
      this.VuelosService.facturacion(vuelo);
    }    
  }

  errorFacturar() {
    const alert = this.alertCtrl.create({
      title: 'Ups',
      subTitle: 'Solo se puede facturar 24 horas antes de la salida del vuelo.',
      buttons: ['OK']
    });
    alert.present();
  }

}
