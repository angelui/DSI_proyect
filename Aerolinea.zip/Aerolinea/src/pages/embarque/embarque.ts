import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { Tarjeta } from '../../models/tarjeta-embarque.model';
import { VuelosService } from '../../services/vuelos.service';
import { Vuelo } from '../../models/vuelo.model';

/**
 * Generated class for the EmbarquePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-embarque',
  templateUrl: 'embarque.html',
})
export class EmbarquePage {

  tarjetas: Tarjeta[] =[];

  constructor(public navCtrl: NavController, public navParams: NavParams, private VuelosService:VuelosService, public alertCtrl: AlertController) {
  }

  ionViewWillEnter() {
    this.tarjetas = this.VuelosService.getTarjetas();
  }

  mostrarTarjeta(vuelo: Vuelo) {
    const alert = this.alertCtrl.create({
      title: 'Tarjeta de embarque',
      message: 'hola',
      
      buttons: ['OK']
    });
    alert.present();
  }  

}
