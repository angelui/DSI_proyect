import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EmbarquePage } from './embarque';

@NgModule({
  declarations: [
    EmbarquePage,
  ],
  imports: [
    IonicPageModule.forChild(EmbarquePage),
  ],
})
export class EmbarquePageModule {}
