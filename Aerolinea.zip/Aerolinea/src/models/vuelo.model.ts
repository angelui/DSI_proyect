export interface Vuelo {
    
    origen: string;
    
    destino: string;
    
    ida: string;
    
    vuelta: string;

    company: string;

    facturado: boolean;
}