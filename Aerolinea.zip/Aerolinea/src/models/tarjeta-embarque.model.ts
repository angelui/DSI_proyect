import { Vuelo } from "./vuelo.model";

export interface Tarjeta {
    
    nombre: string;

    apellidos: string;

    pasaporte: string;

    telefono: number;

    vuelo: Vuelo;
}