export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyC_tENPxo3Bif8ZUQ3Wa6ZdkkSnXegJBBA",
    authDomain: "micor9-e4553.firebaseapp.com",
    databaseURL: "https://micor9-e4553.firebaseio.com",
    projectId: "micor9-e4553",
    storageBucket: "micor9-e4553.appspot.com",
    messagingSenderId: "24601453042"

}