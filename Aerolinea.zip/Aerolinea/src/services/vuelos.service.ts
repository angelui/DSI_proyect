import { Vuelo } from "../models/vuelo.model";
import { Tarjeta } from "../models/tarjeta-embarque.model";
import { AngularFireDatabase } from 'angularfire2/database'

export class VuelosService{

    /*private vuelos: Vuelo []=

    [{"origen":"Madrid","destino":"Paris","ida":"2019-04-23","vuelta":"2019-04-26","company":"Ryanair", "facturado":false},
    {"origen":"Madrid","destino":"Londres","ida":"2019-03-26","vuelta":"2019-05-02","company":"Iberia", "facturado":false},
    {"origen":"Barcelona","destino":"MIlán","ida":"2019-03-26","vuelta":"2019-03-28","company":"Vueling", "facturado":false}];
*/
    private vuelos = this.db.list <Vuelo> ("vuelofirebase")

    private reservas: Vuelo []=[];

    private tarjetas: Tarjeta[]=[];

    private mostrar: Vuelo []=[];

    constructor(private db: AngularFireDatabase){
        
    }

    addVuelo(value: Vuelo){
        this.vuelos.push(value);
    }

    getVuelos(){
        return this.vuelos;
    }

    addReserva(value: Vuelo){
        this.reservas.push(value);
    }

    getReservas(){
        return this.reservas;
    }

    getMostrar(){
        return this.mostrar;
    }

    addMostrar(values: Vuelo){
        this.mostrar.push(values);
    }

    facturacion(value: Vuelo){
        value.facturado = true;
    }

    addTarjeta(vuelo: Vuelo, nom: string, ape: string, pas: string, tel: number){
        this.tarjetas.push({"nombre":nom, "apellidos":ape, "pasaporte":pas, "telefono":tel, "vuelo":vuelo});
    }

    getTarjetas(){
        return this.tarjetas;
    }

    updateVuelo(value: Vuelo){
       
    }

    removeVuelo(value: Vuelo){


    }
}