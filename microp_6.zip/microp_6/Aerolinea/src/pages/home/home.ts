import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {
  }

  slider = [
    {
      title: 'Alberta, Canadá', description: 'Alberta es una de las diez provincias que, junto con los tres territorios, conforman las trece entidades federales de Canadá. Su capital es Edmonton y su ciudad más poblada, Calgary. Está ubicada al oeste del país, limitando al norte con los Territorios del Noroeste, al este con Saskatchewan, al sur con Estados Unidos y al oeste con Columbia Británica.', image: "assets/icon/canada.png"
    },
    {
      title: 'Londres, Reino Unido', description: 'Londres es la capital y mayor ciudad de Inglaterra y del Reino Unido.2​3​ Situada a orillas del río Támesis, Londres es un importante asentamiento humano desde que fue fundada por los romanos con el nombre de Londinium hace casi dos milenios.', image: "assets/icon/londres.png"
    },
    {
      title: 'Punta Cana, República Dominicana', description: 'Punta Cana es una localidad situada al este de la República Dominicana, en la provincia de La Altagracia. En esta localidad se ubican varios complejos hoteleros, cuya superficie total es de unos 420 000 m² (equivalentes a 42 hectáreas o 0,42 km²).', image: "assets/icon/puntaCana.png"
    },
    {
      title: 'Moscú, Rusia', description: 'Moscú es la capital y la entidad federal más poblada de Rusia. La ciudad es un importante centro político, económico, cultural y científico de Rusia y del continente. Moscú es la megaciudad más septentrional de la Tierra, la segunda ciudad de Europa en población después de Estambul, y la sexta del mundo.', image: "assets/icon/moscu.png"
    },
    {
      title: 'Sídney, Australia', description: ' Sídney es la ciudad más grande y poblada de Australia y Oceanía, con una población en su área metropolitana cercana a los 4.92 millones, según una estimación de 2015. ​Es la capital del estado de Nueva Gales del Sur y fue el asentamiento de la primera colonia británica en Australia. ', image: "assets/icon/sidney.png"
    },

  ];

}
