import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Vuelo } from '../../models/vuelo.model';
import { VuelosService } from '../../services/vuelos.service';
import { AlertController } from 'ionic-angular';

/**
 * Generated class for the VuelosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-vuelos',
  templateUrl: 'vuelos.html',
})
export class VuelosPage {
  str:string;
  vuelos: Vuelo[] =[];
  buscador: Vuelo[] = [];
  todo = {origen : this.str, destino: this.str, ida: Date, vuelta: Date};
  constructor(public navCtrl: NavController, public navParams: NavParams, public alertCtrl: AlertController, private VuelosService:VuelosService) {
  }

  ionViewWillEnter() {
    this.vuelos = this.VuelosService.getVuelos();
    this.buscador = this.VuelosService.getMostrar();
  }
  

  showAlert(vuelo: Vuelo) {
    const alert = this.alertCtrl.create({
      title: 'Reserva',
      subTitle: '¿Desea reservar?',
      buttons: [
        {
          text: 'OK',
          handler: () =>{
            this.VuelosService.addReserva(vuelo);
          }
        }]
    });
    alert.present();
  }

  findVuelos(){
    console.log(this.todo.vuelta)

    for(let entry of this.vuelos){
      console.log(entry.ida);
      if(entry.origen == String(this.todo.origen) && entry.destino == String(this.todo.destino) && String(this.todo.ida) == entry.ida && String(this.todo.vuelta) == entry.vuelta ){
        this.VuelosService.addMostrar(entry);
      }
    }

        
  }

}
