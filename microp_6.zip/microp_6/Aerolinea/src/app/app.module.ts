import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { VuelosPage } from '../pages/vuelos/vuelos';
import { ReservasPage } from '../pages/reservas/reservas';
import { EmbarquePage } from '../pages/embarque/embarque';
import { InformacionPage } from '../pages/informacion/informacion';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { VuelosService } from '../services/vuelos.service';
import { Services } from '@angular/core/src/view';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    VuelosPage,
    ReservasPage,
    EmbarquePage,
    InformacionPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    VuelosPage,
    ReservasPage,
    EmbarquePage, 
    InformacionPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    VuelosService
  ]
})
export class AppModule {}
